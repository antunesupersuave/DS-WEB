var capital = Number(prompt("Informe o capital inicial"));

var tempo = Number(prompt("Informe o tempo em meses"));

var taxa = Number(prompt("Informe a taxa de juros"));


var montante = (montante = capital * (1+taxa)**tempo);

alert (montante)