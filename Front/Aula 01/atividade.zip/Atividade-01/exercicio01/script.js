var nome = prompt ("Digite seu nome")

var sobrenome = prompt ("Digite seu sobrenome")

alert (nome + " " + sobrenome)

