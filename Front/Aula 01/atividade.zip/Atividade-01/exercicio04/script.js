var numero = Number(prompt("Digite a temperatura que deseja converter de F para C"));

var resultado = (numero - 32)

alert (resultado * 0.5556)