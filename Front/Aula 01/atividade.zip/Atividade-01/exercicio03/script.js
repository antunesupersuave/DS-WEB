var numero = Number(prompt("Digite o número que deseja ser exibido ao cubo"));

alert (numero ** 3)