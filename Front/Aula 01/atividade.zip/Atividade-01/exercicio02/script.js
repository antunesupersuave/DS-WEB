
let numero1 = Number(prompt("Digite o primeiro número:"));
let numero2 = Number(prompt("Digite o segundo número:"));


let adicao = numero1 + numero2;


let subtracao = numero1 - numero2;


let multiplicacao = numero1 * numero2;


let divisao = numero1 / numero2;

alert(
  "Resultados das operações:\n\n" +
  "Adição: " + adicao + "\n" +
  "Subtração: " + subtracao + "\n" +
  "Multiplicação: " + multiplicacao + "\n" +
  "Divisão: " + divisao
);
